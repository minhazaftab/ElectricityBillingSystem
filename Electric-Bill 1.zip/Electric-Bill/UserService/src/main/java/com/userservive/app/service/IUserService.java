

package com.userservive.app.service;

import com.userservive.app.entity.User;

import java.util.List;
import java.util.Optional;

public interface IUserService {
    // Create a new user
    User createUser(User user);

    // Get all users
    List<User> getAllUsers();

    // Get a user by ID
    Optional<User> getUserById(int userId);

    // Update a user
    User updateUser(int userId, User userDetails);

    // Delete a user
    void deleteUser(int userId);
}






