package com.userservive.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.userservive.app.entity.User;
import com.userservive.app.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/createUser")
	public User createUser(@RequestBody User user) {
		return userService.createUser(user); // Call the service to save the user
	}
	
	
	@PostMapping("/login/{username}/{password}")
	public User loginUser(@PathVariable String username,@PathVariable String password) {
		userService.loginUser(username,password);
		return null; // Call the service to save the user
	}
	

	// Get all users
	@GetMapping
	public ResponseEntity<List<User>> getAllUsers() {
		List<User> users = userService.getAllUsers();
		return ResponseEntity.ok(users);
	}

	// Get a user by ID
	@GetMapping("/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable int userId) {
		Optional<User> user = userService.getUserById(userId);
		return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// Update a user
	@PutMapping("/{userId}")
	public ResponseEntity<User> updateUser(@PathVariable int userId, @RequestBody User userDetails) {
		User updatedUser = userService.updateUser(userId, userDetails);
		return ResponseEntity.ok(updatedUser);
	}

	// Delete a user
	@DeleteMapping("/{userId}")
	public ResponseEntity<Void> deleteUser(@PathVariable int userId) {
		userService.deleteUser(userId);
		return ResponseEntity.noContent().build();
	}
	
	
	
	
	

}
