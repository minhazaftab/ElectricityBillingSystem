package com.userservive.app.service;

 

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.userservive.app.entity.User;

import com.userservive.app.repository.UserRepository;
 
 
@Service
public class UserService {
 
	@Autowired
	private UserRepository userRepository;
	

	
	

    // Create a new user
    public User createUser(User user) {
        return userRepository.save(user);
    }

    // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Get a user by ID
    public Optional<User> getUserById(int userId) {
        return userRepository.findById(userId);
    }

    // Update a user
    public User updateUser(int userId, User userDetails) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
        user.setUserName(userDetails.getUserName());
        user.setUserAddress(userDetails.getUserAddress());
        user.setUserPhoneNo(userDetails.getUserPhoneNo());
        user.setUserPassword(userDetails.getUserPassword());
        user.setConnectiontype(userDetails.getConnectiontype());
        return userRepository.save(user);
    }

    // Delete a user
    public void deleteUser(int userId) {
        userRepository.deleteById(userId);
    }

	public void loginUser(String username, String password) {
		
		
	}
	

	

 
}