package com.billservice.app.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.billservice.app.model.Bill;



@Repository
public interface BillRepository extends CrudRepository<Bill,Integer> {

	List<Bill> findByuserId(int custid);

}
