package com.billservice.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billservice.app.dto.Connection;
import com.billservice.app.dto.User;
import com.billservice.app.model.Bill;
import com.billservice.app.repository.BillRepository;

@Service
public class BillService implements IBillService {

	private final BillRepository billRepository;

	@Autowired
	public BillService(BillRepository billRepository) {
		this.billRepository = billRepository;
	}

	@Autowired
	private UserServiceClient userServiceClient;

	@Autowired
	private ConnectionTypeServiceClient connectionTypeServiceClient;

	// Create a new Bill
	@Override
	public Bill createBill(Bill bill) {
		return billRepository.save(bill);
	}

	// Get all Bills
	@Override
	public List<Bill> getAllBills() {
		return (List<Bill>) billRepository.findAll();
	}

	// Get a Bill by ID
	@Override
	public Optional<Bill> getBillById(int billId) {
		return billRepository.findById(billId);
	}

	// Update a Bill
	@Override
	public Bill updateBill(int billId, Bill billDetails) {
		Bill bill = billRepository.findById(billId)
				.orElseThrow(() -> new RuntimeException("Bill not found with ID: " + billId));
		bill.setConnectionType(billDetails.getConnectionType());
		bill.setUnits(billDetails.getUnits());
		bill.setBillAmount(billDetails.getBillAmount());
		return billRepository.save(bill);
	}

	// Delete a Bill
	@Override
	public void deleteBill(int billId) {
		billRepository.deleteById(billId);
	}

	public Bill generateBill(int userId) {

		User user = userServiceClient.getUserById(userId);

		
		System.out.println(user);
		if (user == null) {
			throw new RuntimeException("User not found for ID: " + userId);
		}

		Connection connection = connectionTypeServiceClient.getConnectionByType(user.getConnectiontype());
		System.out.println(connection);
		if (connection == null) {
			throw new RuntimeException("Connection type not found for ID: " + user.getConnectiontype());
		}

		int units = (int) (Math.random() * 500) + 1;

		int billAmount = units * connection.getUnitPrice();

		Bill bill = new Bill();
		// bill.setBillId((int) (Math.random() * 200) + 1);
		bill.setConnectionType(connection.getConnectionType());
		bill.setUnits(units);
		bill.setBillAmount(billAmount);
		bill.setUserId(userId);
		System.out.println(bill);
		return billRepository.save(bill);
	}

	@Override
	public List<Bill> getBillByCustId(int custid) {
		
		return billRepository.findByuserId(custid);
	}

}
