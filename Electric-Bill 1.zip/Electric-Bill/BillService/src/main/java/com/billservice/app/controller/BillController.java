package com.billservice.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.billservice.app.model.Bill;
import com.billservice.app.service.IBillService;

@RestController
@RequestMapping("/api") // Base URL for Bill endpoints
public class BillController {

    private final IBillService billService;

    @Autowired
    public BillController(IBillService billService) {
        this.billService = billService;
    }

    // Create a new Bill
    @PostMapping
    public ResponseEntity<Bill> createBill(@RequestBody Bill bill) {
        Bill createdBill = billService.createBill(bill);
        return ResponseEntity.ok(createdBill);
    }

    // Get all Bills
    @GetMapping("/allBills")
    public ResponseEntity<List<Bill>> getAllBills() {
        List<Bill> bills = billService.getAllBills();
        return ResponseEntity.ok(bills);
    }

    // Get a Bill by ID
    @GetMapping("/{billId}")
    public ResponseEntity<Bill> getBillById(@PathVariable int billId) {
        Optional<Bill> bill = billService.getBillById(billId);
        return bill.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Update a Bill
    @PutMapping("/{billId}")
    public ResponseEntity<Bill> updateBill(@PathVariable int billId, @RequestBody Bill billDetails) {
        Bill updatedBill = billService.updateBill(billId, billDetails);
        return ResponseEntity.ok(updatedBill);
    }

    // Delete a Bill
    @DeleteMapping("/{billId}")
    public ResponseEntity<Void> deleteBill(@PathVariable int billId) {
        billService.deleteBill(billId);
        return ResponseEntity.noContent().build();
    }
    
    
    @GetMapping("/bill/{id}")
    public Bill generateBill(@PathVariable int id) {
    	System.out.println("userId is:"+id);
    	return billService.generateBill(id);
    }
    
    
    @GetMapping("/bill/{custid}")
    public List<Bill> getBilByCustId(@PathVariable int custid){
    	return billService.getBillByCustId(custid);
    }
    
    
    
}
