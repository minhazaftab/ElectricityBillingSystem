package com.connections.app.service;

import com.connections.app.entity.ConnectionType;
import com.connections.app.repository.ConnectionTypeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ConnectionTypeService implements IConnectionTypeService {

    private final ConnectionTypeRepository connectionTypeRepository;

    @Autowired
    public ConnectionTypeService(ConnectionTypeRepository connectionTypeRepository) {
        this.connectionTypeRepository = connectionTypeRepository;
    }

    // Create a new connection type
    @Override
    public ConnectionType createConnectionType(ConnectionType connectionType) {
        return connectionTypeRepository.save(connectionType);
    }

    // Get all connection types
    @Override
    public List<ConnectionType> getAllConnectionTypes() {
        return connectionTypeRepository.findAll();
    }

    // Get a connection type by ID
    @Override
    public Optional<ConnectionType> getConnectionTypeById(int connectionId) {
        return connectionTypeRepository.findById(connectionId);
    }

    // Update a connection type
    @Override
    public ConnectionType updateConnectionType(int connectionId, ConnectionType connectionTypeDetails) {
        ConnectionType connectionType = connectionTypeRepository.findById(connectionId)
                .orElseThrow(() -> new RuntimeException("Connection type not found with ID: " + connectionId));
        connectionType.setConnectionType(connectionTypeDetails.getConnectionType());
        connectionType.setUnitPrice(connectionTypeDetails.getUnitPrice());
        return connectionTypeRepository.save(connectionType);
    }

    // Delete a connection type
    @Override
    public void deleteConnectionType(int connectionId) {
        connectionTypeRepository.deleteById(connectionId);
    }
    
    
    
    @Override
    public ConnectionType findByConnectionType(String connectionType) {
        return connectionTypeRepository.findByConnectionType(connectionType);
    }
    
    
}
