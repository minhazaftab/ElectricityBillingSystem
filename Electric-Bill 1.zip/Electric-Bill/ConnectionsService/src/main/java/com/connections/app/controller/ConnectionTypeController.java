package com.connections.app.controller;

import com.connections.app.entity.ConnectionType;
import com.connections.app.service.IConnectionTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api") // Base URL for the connection types
public class ConnectionTypeController {

    private final IConnectionTypeService connectionTypeService;

    @Autowired
    public ConnectionTypeController(IConnectionTypeService connectionTypeService) {
        this.connectionTypeService = connectionTypeService;
    }

    // Create a new connection type
    @PostMapping("/connection")
    public ConnectionType createConnectionType(@RequestBody ConnectionType connectionType) {
        ConnectionType createdConnectionType = connectionTypeService.createConnectionType(connectionType);
        return createdConnectionType;
    }

    // Get all connection types
    @GetMapping
    public List<ConnectionType> getAllConnectionTypes() {
        List<ConnectionType> connectionTypes = connectionTypeService.getAllConnectionTypes();
        return connectionTypes;
    }

    // Get a connection type by ID
    @GetMapping("/{connectionId}")
    public Optional<ConnectionType> getConnectionTypeById(@PathVariable int connectionId) {
        Optional<ConnectionType> connectionType = connectionTypeService.getConnectionTypeById(connectionId);
        return connectionType;
    }

    // Update a connection type
    @PutMapping("/{connectionId}")
    public ConnectionType updateConnectionType(@PathVariable int connectionId, @RequestBody ConnectionType connectionTypeDetails) {
        ConnectionType updatedConnectionType = connectionTypeService.updateConnectionType(connectionId, connectionTypeDetails);
        return updatedConnectionType;
    }

    // Delete a connection type
    @DeleteMapping("/{connectionId}")
    public ResponseEntity<Void> deleteConnectionType(@PathVariable int connectionId) {
        connectionTypeService.deleteConnectionType(connectionId);
        return ResponseEntity.noContent().build();
    }
    
    
    
    @GetMapping("/connections/{type}")
    public ConnectionType getConnectionsByType(@PathVariable String type) {
        return connectionTypeService.findByConnectionType(type);
    }
    
    
    
}
