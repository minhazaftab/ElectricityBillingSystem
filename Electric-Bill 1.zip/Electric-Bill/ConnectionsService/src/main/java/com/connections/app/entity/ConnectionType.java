package com.connections.app.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="connection_details")
public class ConnectionType {
	
	@Id
	private int connectionId;
	private String connectionType;
	private int unitPrice;

}
