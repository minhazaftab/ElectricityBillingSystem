package com.connections.app.service;

import java.util.List;
import java.util.Optional;

import com.connections.app.entity.ConnectionType;

public interface IConnectionTypeService {
    // Create a new connection type
    ConnectionType createConnectionType(ConnectionType connectionType);

    // Get all connection types
    List<ConnectionType> getAllConnectionTypes();

    // Get a connection type by ID
    Optional<ConnectionType> getConnectionTypeById(int connectionId);

    // Update a connection type
    ConnectionType updateConnectionType(int connectionId, ConnectionType connectionTypeDetails);

    // Delete a connection type
    void deleteConnectionType(int connectionId);

	ConnectionType findByConnectionType(String type);
}