package com.user.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.user.app.model.Customer;

@Repository
public interface IUserRepository extends JpaRepository<Customer, Integer> {

}
