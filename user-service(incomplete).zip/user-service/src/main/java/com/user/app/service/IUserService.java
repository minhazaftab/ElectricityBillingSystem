package com.user.app.service;

import java.util.List;

import com.user.app.model.Admin;
import com.user.app.model.Customer;

public interface IUserService {

	public List<Customer> findAllCustomers();

	public Customer findCustomerById(Integer id);

	public Admin findAdminByUsernamed(String username);

}
