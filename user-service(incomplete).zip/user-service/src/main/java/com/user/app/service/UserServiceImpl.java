package com.user.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.app.model.Admin;
import com.user.app.model.Customer;
import com.user.app.repository.IUserRepository;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserRepository userRepository;

	@Override
	public List<Customer> findAllCustomers() {
		List<Customer> customerList = userRepository.findAll();
		return customerList;
	}

	@Override
	public Customer findCustomerById(Integer id) {
		Customer customer = userRepository.findById(id).get();
		return customer;
	}

	@Override
	public Admin findAdminByUsername(String username) {
		Admin admin = userRepository.findby
		return null;
	}

}
