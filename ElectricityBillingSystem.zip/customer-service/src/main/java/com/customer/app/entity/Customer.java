package com.customer.app.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
 
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "customers")
public class Customer {
	@Id
	private int customerId;
	private String customerName;
	private String customerAddress;
	private long customerPhoneNo;
	private String customerPassword;
	private String connectiontype;
 
}
