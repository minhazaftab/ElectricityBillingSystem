package com.customer.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.app.entity.Customer;
import com.customer.app.repository.ICustomerRepository;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private ICustomerRepository customerRepository;

	// Create a new customer
	@Override
	public Customer createCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	// Get all customers
	@Override
	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	// Get a customer by ID
	@Override
	public Optional<Customer> getCustomerById(int customerId) {
		return customerRepository.findById(customerId);
	}

	// Update a customer
	@Override
	public Customer updateCustomer(int customerId, Customer customerDetails) {
		Customer customer = customerRepository.findById(customerId)
				.orElseThrow(() -> new RuntimeException("Customer not found with ID: " + customerId));
		customer.setCustomerName(customerDetails.getCustomerName());
		customer.setCustomerAddress(customerDetails.getCustomerAddress());
		customer.setCustomerPhoneNo(customerDetails.getCustomerPhoneNo());
		customer.setCustomerPassword(customerDetails.getCustomerPassword());
		customer.setConnectiontype(customerDetails.getConnectiontype());
		return customerRepository.save(customer);
	}

	// Delete a customer
	@Override
	public void deleteCustomer(int customerId) {
		customerRepository.deleteById(customerId);
	}

	public void loginCustomer(String customername, String password) {

	}
}