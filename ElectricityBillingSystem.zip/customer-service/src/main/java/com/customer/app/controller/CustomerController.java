package com.customer.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.app.entity.Customer;
import com.customer.app.service.CustomerServiceImpl;

@RestController
@RequestMapping("/api")
public class CustomerController {

	@Autowired
	private CustomerServiceImpl customerService;

	@PostMapping("/createCustomer")
	public Customer createCustomer(@RequestBody Customer customer) {
		return customerService.createCustomer(customer); // Call the service to save the customer
	}
	
	
	@PostMapping("/login/{customerName}/{password}")
	public Customer loginCustomer(@PathVariable String customerName,@PathVariable String password) {
		customerService.loginCustomer(customerName,password);
		return null; // Call the service to save the customer
	}
	

	// Get all customers
	@GetMapping
	public ResponseEntity<List<Customer>> getAllCustomers() {
		List<Customer> customers = customerService.getAllCustomers();
		return ResponseEntity.ok(customers);
	}

	// Get a customer by ID
	@GetMapping("/{customerId}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable int customerId) {
		Optional<Customer> customer = customerService.getCustomerById(customerId);
		return customer.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
	}

	// Update a customer
	@PutMapping("/{customerId}")
	public ResponseEntity<Customer> updateCustomer(@PathVariable int customerId, @RequestBody Customer customerDetails) {
		Customer updatedCustomer = customerService.updateCustomer(customerId, customerDetails);
		return ResponseEntity.ok(updatedCustomer);
	}

	// Delete a customer
	@DeleteMapping("/{customerId}")
	public ResponseEntity<Void> deleteCustomer(@PathVariable int customerId) {
		customerService.deleteCustomer(customerId);
		return ResponseEntity.noContent().build();
	}
	
	
	
	
	

}
