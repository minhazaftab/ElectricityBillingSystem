package com.customer.app.service;

import java.util.List;
import java.util.Optional;

import com.customer.app.entity.Customer;

	public interface ICustomerService {
	    // Create a new user
	    Customer createCustomer(Customer customer);

	    // Get all users
	    List<Customer> getAllCustomers();

	    // Get a user by ID
	    Optional<Customer> getCustomerById(int customerId);

	    // Update a user
	    Customer updateCustomer(int customerId, Customer customerDetails);

	    // Delete a user
	    void deleteCustomer(int customerId);
	}

