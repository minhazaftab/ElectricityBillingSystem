package com.bill.app.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bill.app.dto.Customer;

@FeignClient(name = "customer-service", url = "http://localhost:8081")
public interface CustomerServiceClient {
	
	
	 @GetMapping("/Customer/api/{customerId}")
	    Customer getCustomerById(@PathVariable("customerId") int customerId);

}
