package com.bill.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bill.app.model.Bill;

@Repository
public interface IBillRepository extends JpaRepository<Bill, Integer> {

	List<Bill> findByCustomerId(int custid);
	
}
