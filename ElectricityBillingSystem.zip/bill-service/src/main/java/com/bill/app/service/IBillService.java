package com.bill.app.service;

import java.util.List;
import java.util.Optional;

import com.bill.app.model.Bill;

public interface IBillService {

	Bill createBill(Bill bill);

	// Get all Bills
	List<Bill> getAllBills();

	// Get a Bill by ID
	Optional<Bill> getBillById(int billId);

	// Update an existing Bill
	Bill updateBill(int billId, Bill billDetails);

	// Delete a Bill by ID
	void deleteBill(int billId);

	Bill generateBill(int id);

	List<Bill> getBillByCustId(int custid);

}
