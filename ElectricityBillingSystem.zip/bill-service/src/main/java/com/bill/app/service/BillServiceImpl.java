package com.bill.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bill.app.dto.Connection;
import com.bill.app.dto.Customer;
import com.bill.app.model.Bill;
import com.bill.app.repository.IBillRepository;

@Service
public class BillServiceImpl implements IBillService {

	private final IBillRepository billRepository;

	@Autowired
	public BillServiceImpl(IBillRepository billRepository) {
		this.billRepository = billRepository;
	}

	@Autowired
	private CustomerServiceClient customerServiceClient;

	@Autowired
	private ConnectionServiceClient connectionTypeServiceClient;

	// Create a new Bill
	@Override
	public Bill createBill(Bill bill) {
		return billRepository.save(bill);
	}

	// Get all Bills
	@Override
	public List<Bill> getAllBills() {
		return (List<Bill>) billRepository.findAll();
	}

	// Get a Bill by ID
	@Override
	public Optional<Bill> getBillById(int billId) {
		return billRepository.findById(billId);
	}

	// Update a Bill
	@Override
	public Bill updateBill(int billId, Bill billDetails) {
		Bill bill = billRepository.findById(billId)
				.orElseThrow(() -> new RuntimeException("Bill not found with ID: " + billId));
		bill.setConnectionType(billDetails.getConnectionType());
		bill.setUnits(billDetails.getUnits());
		bill.setBillAmount(billDetails.getBillAmount());
		return billRepository.save(bill);
	}

	// Delete a Bill
	@Override
	public void deleteBill(int billId) {
		billRepository.deleteById(billId);
	}

	public Bill generateBill(int customerId) {

		Customer customer = customerServiceClient.getCustomerById(customerId);

		System.out.println(customer);
		if (customer == null) {
			throw new RuntimeException("Customer not found for ID: " + customerId);
		}

		Connection connection = connectionTypeServiceClient.getConnectionByType(customer.getConnectionType());
		System.out.println(connection);
		if (connection == null) {
			throw new RuntimeException("Connection type not found for ID: " + customer.getConnectionType());
		}

		int units = (int) (Math.random() * 500) + 1;

		int billAmount = units * connection.getUnitPrice();

		Bill bill = new Bill();
		// bill.setBillId((int) (Math.random() * 200) + 1);
		bill.setConnectionType(connection.getConnectionType());
		bill.setUnits(units);
		bill.setBillAmount(billAmount);
		bill.setCustomerId(customerId);
		System.out.println(bill);
		return billRepository.save(bill);
	}

	@Override
	public List<Bill> getBillByCustId(int customerId) {

		return billRepository.findByCustomerId(customerId);
	}

}
