package com.bill.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {
	private int customerId;
	private String customerName;
	private String customerAddress;
	private long customerPhoneNo;
	private String customerPassword;
	private String connectionType;

}
