package com.bill.app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Connection {

	private int connectionId;
	private String connectionType;
	private int unitPrice;

}
