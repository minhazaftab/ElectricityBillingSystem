package com.connection.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.connection.app.entity.Connection;

@Repository
public interface IConnectionRepository extends JpaRepository<Connection, Integer> {

	Connection findByConnectionType(String connectionType);

}
