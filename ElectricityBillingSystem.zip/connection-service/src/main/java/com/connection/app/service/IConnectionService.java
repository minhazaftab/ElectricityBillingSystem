package com.connection.app.service;

import java.util.List;
import java.util.Optional;

import com.connection.app.entity.Connection;

public interface IConnectionService {
    // Create a new connection type
    Connection createConnection(Connection connection);

    // Get all connection types
    List<Connection> getAllConnections();

    // Get a connection type by ID
    Optional<Connection> getConnectionById(int connectionId);

    // Update a connection type
    Connection updateConnection(int connectionId, Connection connectionDetails);

    // Delete a connection type
    void deleteConnection(int connectionId);

	Connection findByConnectionType(String connectionType);
}
