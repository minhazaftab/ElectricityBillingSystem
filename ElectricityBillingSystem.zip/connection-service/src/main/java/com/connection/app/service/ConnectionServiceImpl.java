package com.connection.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.connection.app.entity.Connection;
import com.connection.app.repository.IConnectionRepository;

@Service
public class ConnectionServiceImpl implements IConnectionService {

	@Autowired
    private IConnectionRepository connectionRepository;

    public ConnectionServiceImpl(IConnectionRepository connectionRepository) {
        this.connectionRepository = connectionRepository;
    }

    // Create a new connection type
    @Override
    public Connection createConnection(Connection connection) {
        return connectionRepository.save(connection);
    }

    // Get all connection types
    @Override
    public List<Connection> getAllConnections() {
        return connectionRepository.findAll();
    }

    // Get a connection type by ID
    @Override
    public Optional<Connection> getConnectionById(int connectionId) {
        return connectionRepository.findById(connectionId);
    }

    // Update a connection type
    @Override
    public Connection updateConnection(int connectionId, Connection connectionDetails) {
        Connection connection = connectionRepository.findById(connectionId)
                .orElseThrow(() -> new RuntimeException("Connection type not found with ID: " + connectionId));
        connection.setConnectionType(connectionDetails.getConnectionType());
        connection.setUnitPrice(connectionDetails.getUnitPrice());
        return connectionRepository.save(connection);
    }

    // Delete a connection type
    @Override
    public void deleteConnection(int connectionId) {
        connectionRepository.deleteById(connectionId);
    }
    
    
 // Get a connection type by type
    @Override
    public Connection findByConnectionType(String connectionType) {
        return connectionRepository.findByConnectionType(connectionType);
    }
    
    
}
