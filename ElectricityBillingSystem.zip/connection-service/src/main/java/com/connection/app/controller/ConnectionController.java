package com.connection.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.connection.app.entity.Connection;
import com.connection.app.service.IConnectionService;

@RestController
@RequestMapping("/api") // Base URL for the connection types
public class ConnectionController {

    private final IConnectionService connectionService;

    @Autowired
    public ConnectionController(IConnectionService connectionService) {
        this.connectionService = connectionService;
    }

    // Create a new connection type
    @PostMapping("/connection")
    public Connection createConnection(@RequestBody Connection connection) {
        Connection createdConnection = connectionService.createConnection(connection);
        return createdConnection;
    }

    // Get all connection types
    @GetMapping
    public List<Connection> getAllConnections() {
        List<Connection> connections = connectionService.getAllConnections();
        return connections;
    }

    // Get a connection type by ID
    @GetMapping("/{connectionId}")
    public Optional<Connection> getConnectionById(@PathVariable int connectionId) {
        Optional<Connection> connection = connectionService.getConnectionById(connectionId);
        return connection;
    }

    // Update a connection type
    @PutMapping("/{connectionId}")
    public Connection updateConnection(@PathVariable int connectionId, @RequestBody Connection connectionDetails) {
        Connection updatedConnection = connectionService.updateConnection(connectionId, connectionDetails);
        return updatedConnection;
    }

    // Delete a connection type
    @DeleteMapping("/{connectionId}")
    public ResponseEntity<Void> deleteConnection(@PathVariable int connectionId) {
        connectionService.deleteConnection(connectionId);
        return ResponseEntity.noContent().build();
    }
    
    
    
    @GetMapping("/connections/{connectionType}")
    public Connection getConnectionsByConnectionType(@PathVariable String connectionType) {
        return connectionService.findByConnectionType(connectionType);
    }
    
    
    
}
